package com.example.yearbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YearbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
